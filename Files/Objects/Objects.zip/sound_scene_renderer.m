classdef sound_scene_renderer < handle
    %RENDERER Summary of this class goes here
    %   Detailed explanation goes here
    % TODO: make input, rendeder out and binauarl buses
    % and "wire" them up
    properties
        SFS_renderer
        decorrelator
        binaural_renderer
        directivity_tables
        HRTF_extrapolators
    end

    methods
        function obj = sound_scene_renderer(virtual_sources,loudspeaker_array,headphone, receiver, setup)

            % Get all required directivity characteristics
            N_fft = 2^nextpow2( min(setup.Block_size + size(setup.HRTF.Data.IR,3), 2*setup.Block_size) - 1 );
            cnt = 0;
            for n = 1 : length(virtual_sources)
                if isempty(get_dirtable_idx( obj.directivity_tables, virtual_sources{n}))
                    cnt = cnt + 1;
                    obj.directivity_tables{cnt} = directivity_table(virtual_sources{n}.source_type, N_fft, setup.SampleRate);
                end
            end
            for m = 1 : length(loudspeaker_array)
                if isempty(get_dirtable_idx( obj.directivity_tables, loudspeaker_array{m}))
                    cnt = cnt + 1;
                    obj.directivity_tables{cnt} = directivity_table(loudspeaker_array{m}.source_type, N_fft, setup.SampleRate);
                end
            end

            for n = 1 : length(virtual_sources)
                idx = get_dirtable_idx(obj.directivity_tables,virtual_sources{n});
                switch virtual_sources{n}.renderer_type
                    case 'Direct_playback'
                        obj.SFS_renderer{n} = direct_renderer(virtual_sources{n}, loudspeaker_array);
                    case 'VBAP'
                        obj.SFS_renderer{n} = vbap_renderer(virtual_sources{n}, loudspeaker_array);
                    case 'DBAP'
                        obj.SFS_renderer{n} = dbap_renderer(virtual_sources{n}, loudspeaker_array);
                    case 'WFS'
                        obj.SFS_renderer{n} = wfs_renderer(virtual_sources{n}, loudspeaker_array, setup.Renderer_setup);
                    case 'LWFS_foc'
                        obj.SFS_renderer{n} = lwfs_foc_renderer(virtual_sources{n}, loudspeaker_array, setup.SampleRate);
                    case 'LWFS_nara'
                        obj.SFS_renderer{n} = lwfs_renderer_nara(virtual_sources{n}, loudspeaker_array, setup.SampleRate);
                    case 'Nara'
                        obj.SFS_renderer{n} = nara_renderer(virtual_sources{n}, loudspeaker_array, setup.SampleRate);
                    case 'HOA'
                        obj.SFS_renderer{n} = hoa_renderer(virtual_sources{n}, loudspeaker_array, setup.SampleRate,setup.Renderer_setup.HOAorder);
                    case 'NFC_HOA'
                        obj.SFS_renderer{n} = nfc_hoa_renderer(virtual_sources{n}, loudspeaker_array, setup.Renderer_setup.HOAorder);
                    case 'VBAP_WFS'
                        obj.SFS_renderer{n} = vbap_wfs_renderer(virtual_sources{n}, loudspeaker_array, setup.SampleRate );
                    case 'TD_stereo'
                        obj.SFS_renderer{n} = time_delay_renderer(virtual_sources{n}, loudspeaker_array, setup.SampleRate);
                    case 'CTC'
                        obj.SFS_renderer{n} = ctc_renderer(virtual_sources{n}, loudspeaker_array, receiver, setup.SampleRate, setup.Renderer_setup.Plant_model, setup.Renderer_setup.VS_model, setup.Renderer_setup.HRTF_database,setup.Renderer_setup.N_filt);
                    case 'Dolby_surround'
                        obj.SFS_renderer{n} = dolby_surround_renderer(virtual_sources{n}, loudspeaker_array);
                    case 'Room_simulator'
                        obj.SFS_renderer{n} = room_renderer(virtual_sources{n},receiver, loudspeaker_array, setup.Renderer_setup);
        		end
            end

            if length(size(setup.HRTF.Data.IR)) > 3
                %We have BRIRs
                obj.HRTF_extrapolators = brir_extrapolator(setup.HRTF);
            else
                obj.HRTF_extrapolators = hrtf_extrapolator(setup.HRTF,setup.HRTF_extrapolation);
            end

            for n = 1 : length(loudspeaker_array)
                idx = get_dirtable_idx(obj.directivity_tables,loudspeaker_array{n});
                obj.binaural_renderer{n} = binaural_renderer(loudspeaker_array{n}, receiver,headphone, obj.directivity_tables{idx},obj.HRTF_extrapolators);
            end
            obj.decorrelator = decorrelator(setup.Decorrelation,loudspeaker_array, 1);

        end

        function update_SFS_renderers(obj, type)
            cellfun( @(x) x.update_renderer(type), obj.SFS_renderer);
        end

        function update_renderer_settings(obj, setup)
            cellfun( @(x) x.update_settings(setup), obj.SFS_renderer);
        end

        function update_binaural_renderers(obj, type, N)
            if isempty(N)
                cellfun( @(x) x.update_renderer(type), obj.binaural_renderer);
            else
                obj.binaural_renderer{N}.update_renderer(type);
            end
        end

        function render(obj, input, binaural_mode)
            for m = 1 : length(obj.SFS_renderer)
                obj.SFS_renderer{m}.virtual_source.source_signal.set_signal(input(:,m));
                obj.SFS_renderer{m}.render;
            end
            if obj.decorrelator.mode
                obj.decorrelator.render;
            end
            if binaural_mode
                cellfun( @(x) x.render, obj.binaural_renderer);
            end
        end
    end
end